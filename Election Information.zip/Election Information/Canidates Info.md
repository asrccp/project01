
files and links


DISTRICT ATTORNEY 

Larry Krasner - https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Larry_Krasner%2C_Candidate_for_Philadelphia_District_Attorney_%28cropped%29.jpg/500px-Larry_Krasner%2C_Candidate_for_Philadelphia_District_Attorney_%28cropped%29.jpg?20200224142454
LK 2 - https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Larry_Krasner.jpg

https://krasnerforda.com/

Pat Dugan : https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Pat_Dugan-e1759169108628.png

CITY CONTROLLER

Christy Brady : 
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Christy_Brady.jpg

Repub - Ari Patrinos : https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/AriPatrinosPhotograph.jpg

JUDGE OF THE SUPERIOR COURT

Brandon Neuman
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Brandon_Neuman-e1759169068713.jpg

Maria Battista
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2023/03/Maria_Battista-e1680275555660.jpg

Daniel S. Wassmer
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/daniel-wassmer-small.jpg

JUDGE OF THE COMMONWEALTH COURT

Stella Tsai
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Stella_Tsai.jpg

Matthew Wolford
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Matthew_WOlford-e1759169009113.jpg

JUDGE OF THE COURT OF COMMON PLEAS

Will Braveman
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Will_Braveman-e1759168988605.jpeg

Leon A King II
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Leon_King__Sabina_Pierce_HED.jpg

Larry Farnese
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Larry_Farnese.jpg

Brian Kisielewski
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Brian-Kisielewski-e1759168959632.jpg

Irina Ehrlich
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Irina_Ehrlich-e1759168940631.jpg

Anthony Stefanski
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Anthony_Stefanski.jpg

Deborah Watson-Stokes
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Deborah_Watson_Stokes-e1759168901374.jpg

Sarah Jones
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Sarah_Jones-e1759168770549.png

Kia Ghee
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Kia-Ghee-Eneanya.jpeg

Jennifer A. Santiago
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/Jennifer_Santiago-e1759168742269.png

JUDGE OF THE MUNICIPAL COURT

Sherrie Cohen
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/SherrieCohen-1-1-e1759169142927.jpg

Amanda Davidson
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Amanda_Davison-e1759169159192.jpg

Cortez Patton
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/04/Cortez_Patton-e1759169241200.png

SUPREME COURT OF PA

Christine Donohue
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/christine_donohue.jpg

Kevin M. Dougherty
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/Kevin_M_DOUGHERTY.jpg

David Wecht
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/david-wecht.png

SUPERIOR COURT OF PA

Alice Beck Dubow
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/Alice-Beck-Dubow_headshot-scaled-1.jpg

COMMONWEALTH COURT OF PA

Michael H. Wojcik
https://thephiladelphiacitizen.org/nitropack_static/rjCplBTregrNqOsSFAbNvRgdiyEHCCRe/assets/images/optimized/rev-078ace8/thephiladelphiacitizen.org/wp-content/uploads/2025/09/michael_j_Wojcik.png

